% Load phase data
left_data = readmatrix('phase_left.txt', 'FileType', 'text', 'NumHeaderLines', 2);
right_data = readmatrix('phase_right.txt', 'FileType', 'text', 'NumHeaderLines', 2);

% Extract phase values
theta = left_data(:, 1); % Angles (in degrees)
phase_left = left_data(:, 2); % Phase data from the left feed
phase_right = right_data(:, 2); % Phase data from the right feed

% Compute phase difference
phase_difference = phase_left - phase_right;

% Normalize phase difference for BPSK (map to -1 and +1)
modulated_signal = sign(cosd(phase_difference)); 

% Simulate transmission
snr_dB = 0:2:20; % SNR range in dB
num_bits = 1e6; % Number of bits for simulation
ber = zeros(size(snr_dB)); % Initialize BER array

% Generate random data for BPSK
data = randi([0 1], num_bits, 1); % Binary data (0 or 1)
bpsk_signal = 2*data - 1; % Map to -1 and 1

% Loop through SNR values
for i = 1:length(snr_dB)
    % Add Gaussian noise to the signal
    snr_linear = 10^(snr_dB(i)/10);
    noise = (1/sqrt(2*snr_linear)) * (randn(size(bpsk_signal)) + 1i*randn(size(bpsk_signal)));
    received_signal = bpsk_signal + noise;
    
    % Decode received signal
    received_bits = real(received_signal) > 0; % Decision rule: positive -> 1, negative -> 0
    
    % Calculate BER
    ber(i) = sum(received_bits ~= data) / num_bits;
end

% Plot BER vs. SNR
figure;
semilogy(snr_dB, ber, 'b-o', 'LineWidth', 1.5);
grid on;
xlabel('SNR (dB)');
ylabel('Bit Error Rate (BER)');
title('BER vs. SNR for BPSK Modulation');
legend('Simulated BER');
