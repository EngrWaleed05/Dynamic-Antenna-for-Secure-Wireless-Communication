% Step 1: Load and Process Data
left_data = readmatrix('phase_left.txt', 'Range', [3 1]);
right_data = readmatrix('phase_right.txt', 'Range', [3 1]);

phase_left = double(left_data(:, 2));  % Extract and convert to double
phase_right = double(right_data(:, 2));

% Remove NaN or Inf values (if present)
phase_left = phase_left(~isnan(phase_left) & ~isinf(phase_left));
phase_right = phase_right(~isnan(phase_right) & ~isinf(phase_right));

% Normalize the data
phase_left = phase_left / max(abs(phase_left));
phase_right = phase_right / max(abs(phase_right));

% Step 2: Define Discrete Time Vector
Ts = 0.01;  % Sample time
time_vector = (0:length(phase_left) - 1)' * Ts;

% Step 3: Create Time Series Objects
left_signal = timeseries(phase_left, time_vector);
right_signal = timeseries(phase_right, time_vector);

% Verify Signals
disp(left_signal);
disp(right_signal);
% Generate random binary data (0 or 1) for BPSK modulation
data_bits = randi([0, 1], length(phase_left), 1);  % Random binary data

% Create BPSK modulator baseband
bpsk_mod = comm.BPSKModulator;

% Apply BPSK modulation to the data bits
modulated_signal = bpsk_mod(data_bits);
