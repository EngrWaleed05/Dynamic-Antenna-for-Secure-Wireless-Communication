% Load phase data
left_data = readmatrix('phase_left.txt', 'FileType', 'text', 'NumHeaderLines', 2);
right_data = readmatrix('phase_right.txt', 'FileType', 'text', 'NumHeaderLines', 2);

% Extract phase values
theta = left_data(:, 1); % Angles (in degrees)
phase_left = left_data(:, 2); % Phase data from the left feed
phase_right = right_data(:, 2); % Phase data from the right feed

% Simulation parameters
num_bits = 1e5; % Number of bits for simulation (must be even for QPSK)
snr_dB = 10; % Fixed SNR for BER vs. Theta (adjust as needed)
snr_linear = 10^(snr_dB / 10);

% Generate random binary data and reshape into pairs for QPSK
data = randi([0 1], num_bits, 1); % Binary data (0 or 1)
data_pairs = reshape(data, [], 2); % Group into pairs of bits

% Map pairs to QPSK symbols (Gray coding: 00 -> -1-j, 01 -> -1+j, 10 -> +1-j, 11 -> +1+j)
qpsk_signal = (2 * data_pairs(:, 1) - 1) + 1j * (2 * data_pairs(:, 2) - 1);

% Initialize BER array
ber_theta = zeros(length(theta), 1);

% Loop through angles (Theta)
for k = 1:length(theta)
    % Apply modulation separately
    modulated_left = cosd(phase_left(k)) * qpsk_signal; % Modulation for left
    modulated_right = cosd(phase_right(k)) * qpsk_signal; % Modulation for right
    
    % Add Gaussian noise to both signals
    noise_left = (1/sqrt(2 * snr_linear)) * (randn(size(qpsk_signal)) + 1i * randn(size(qpsk_signal)));
    noise_right = (1/sqrt(2 * snr_linear)) * (randn(size(qpsk_signal)) + 1i * randn(size(qpsk_signal)));
    
    received_left = modulated_left + noise_left; % Left signal with noise
    received_right = modulated_right + noise_right; % Right signal with noise
    
    % Take difference between received signals
    received_difference = received_left - received_right;
    
    % Decode received QPSK symbols back into bits
    decoded_bits = zeros(num_bits, 1);
    decoded_bits(1:2:end) = real(received_difference) > 0; % First bit
    decoded_bits(2:2:end) = imag(received_difference) > 0; % Second bit
    
    % Calculate BER for this angle
    ber_theta(k) = sum(decoded_bits ~= data) / num_bits;
end

% Plot BER vs. Theta
figure;
plot(theta, ber_theta, 'g-o', 'LineWidth', 1.5);
grid on;
xlabel('\Theta (degrees)');
ylabel('Bit Error Rate (BER)');
title('BER vs. Theta for QPSK Modulation (Separate Modulation)');
legend(['SNR = ' num2str(snr_dB) ' dB']);
