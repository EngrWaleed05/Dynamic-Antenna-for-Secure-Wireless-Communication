
% Load phase data
left_data = readmatrix('phase_left.txt', 'FileType', 'text', 'NumHeaderLines', 2);
right_data = readmatrix('phase_right.txt', 'FileType', 'text', 'NumHeaderLines', 2);

% Extract phase values
theta = left_data(:, 1); % Angles (in degrees)
phase_left = left_data(:, 2); % Phase data from the left feed
phase_right = right_data(:, 2); % Phase data from the right feed

% Compute phase difference
phase_difference = phase_left - phase_right;

% Normalize phase difference for BPSK (map to -1 and +1)
modulated_signal = sign(cosd(phase_difference)); 

% Simulation parameters
num_bits = 1e5; % Number of bits for simulation
snr_dB = 10; % Fixed SNR for BER vs. Theta (adjust as needed)
snr_linear = 10^(snr_dB / 10);

% Generate random data for BPSK
data = randi([0 1], num_bits, 1); % Binary data (0 or 1)
bpsk_signal = 2 * data - 1; % Map to -1 and 1

% Initialize BER array
ber_theta = zeros(length(theta), 1);

% Loop through angles (Theta)
for k = 1:length(theta)
    % Phase adjustment for each angle
    phase_adjusted_signal = modulated_signal(k) * bpsk_signal;
    
    % Add Gaussian noise to the signal
    noise = (1/sqrt(2 * snr_linear)) * (randn(size(bpsk_signal)) + 1i * randn(size(bpsk_signal)));
    received_signal = phase_adjusted_signal + noise;
    
    % Decode received signal
    received_bits = real(received_signal) > 0; % Decision rule: positive -> 1, negative -> 0
    
    % Calculate BER for this angle
    ber_theta(k) = sum(received_bits ~= data) / num_bits;
end

% Plot BER vs. Theta
figure;
plot(theta, ber_theta, 'r-o', 'LineWidth', 1.5);
grid on;
xlabel('\Theta (degrees)');
ylabel('Bit Error Rate (BER)');
title('BER vs. Theta for BPSK Modulation');
legend(['SNR = ' num2str(snr_dB) ' dB']);
